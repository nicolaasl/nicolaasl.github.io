testpattern({
	Image: {
        xmlns:    'http://schemas.microsoft.com/deepzoom/2008',
		Format:   'jpg',
		Overlap:  1,
		TileSize: 254,
		Size:{
			Height: 1000,
			Width:  1000
		}
	}
});
