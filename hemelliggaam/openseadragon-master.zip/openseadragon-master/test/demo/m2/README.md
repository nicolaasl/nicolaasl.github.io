# M2 Demo

This is an advanced demo/testbed, for proposed improvements to the new version of the Mirador project:

https://github.com/IIIF/m2/

You can see a previous version of Mirador here:

http://showcase.iiif.io/viewer/mirador/

## To Do

* Cropped images

### Maybe

* Alternates: wait until tiles have loaded before switching
* Show/hide pages?
* Lazyloading tilesources?
